---
layout: default
title: Getting started
has_children: true
nav_order: 2
permalink: /getting-started/
---

# Getting started

These pages walk you through the process of setting up FuzzBench locally for
integrating a fuzzer to use in the FuzzBench service. Other users who wish to
develop FuzzBench should also start here as this explains the prequisites for
develolpment and testing.
