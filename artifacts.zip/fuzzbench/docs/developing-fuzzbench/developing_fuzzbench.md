---
layout: default
title: Developing FuzzBench
has_children: true
nav_order: 3
permalink: /developing-fuzzbench/
---

# Developing FuzzBench

This section walks you through making code changes to FuzzBench that aren't
fuzzer integrations. They assume you have already read the docs on
[Getting started]({{site.baseurl }}/getting-started/).
