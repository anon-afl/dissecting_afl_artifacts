There are two artifacts for the paper 'Dissection American Fuzzy Lop - A Fuzzbench Evaluation'.

The first, in the AFL/ folder, is the patched AFL. You can enable the variants used in the paper with compile time or runtime flags.

The second, is the fuzzbench/ snapshot used for our evaluation, you can find the setup to run the AFL variants in fuzzbench/fuzzers/ (e.g. afl_score_min)
